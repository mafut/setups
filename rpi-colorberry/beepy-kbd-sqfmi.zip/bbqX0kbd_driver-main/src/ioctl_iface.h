#ifndef IOCTL_IFACE_H_
#define IOCTL_IFACE_H_

int ioctl_probe(void);
void ioctl_shutdown(void);

#endif
